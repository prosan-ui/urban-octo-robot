import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { pool } from './db.js';
import { requireAuth } from './auth.js';

const app = express();
const PORT = Number(process.env.PORT || 4000);
if (process.env.NODE_ENV === 'production' && (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32)) {
  throw new Error('JWT_SECRET must be configured with at least 32 characters in production.');
}
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: (process.env.CLIENT_URL || 'http://localhost:5173').split(',').map(s => s.trim()), methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS'] }));
app.use(express.json({ limit: '1mb' }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use('/api/contact', rateLimit({ windowMs: 60 * 60 * 1000, limit: 12, standardHeaders: 'draft-7', legacyHeaders: false }));
const asyncRoute = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const clean = v => typeof v === 'string' ? v.trim() : '';
const slugify = s => clean(s).toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 70) || 'portfolio';
const arrayOfStrings = value => Array.isArray(value) ? value.map(v => clean(String(v))).filter(Boolean).slice(0, 30) : [];
function tokenFor(user) { return jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '7d' }); }
async function portfolioForUser(userId) {
  const result = await pool.query('SELECT * FROM portfolios WHERE user_id=$1', [userId]);
  return result.rows[0] || null;
}
app.get('/api/health', asyncRoute(async (_req, res) => {
  await pool.query('SELECT 1');
  res.json({ status: 'ok', database: 'connected' });
}));
app.post('/api/auth/register', asyncRoute(async (req, res) => {
  const name = clean(req.body.name), email = clean(req.body.email).toLowerCase(), password = req.body.password;
  if (name.length < 2 || name.length > 100) return res.status(400).json({ error: 'Name must be between 2 and 100 characters.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (typeof password !== 'string' || password.length < 8 || password.length > 72) return res.status(400).json({ error: 'Password must be 8–72 characters.' });
  const hash = await bcrypt.hash(password, 12);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const u = await client.query('INSERT INTO users(name,email,password_hash) VALUES($1,$2,$3) RETURNING id,name,email', [name,email,hash]);
    const base = slugify(name);
    let slug = base, n = 2;
    while ((await client.query('SELECT 1 FROM portfolios WHERE slug=$1', [slug])).rowCount) slug = `${base}-${n++}`;
    const p = await client.query('INSERT INTO portfolios(user_id,slug) VALUES($1,$2) RETURNING *', [u.rows[0].id,slug]);
    await client.query('COMMIT');
    res.status(201).json({ token: tokenFor(u.rows[0]), user: u.rows[0], portfolio: p.rows[0] });
  } catch (e) { await client.query('ROLLBACK'); if (e.code === '23505') return res.status(409).json({ error: 'An account with this email already exists.' }); throw e; }
  finally { client.release(); }
}));
app.post('/api/auth/login', asyncRoute(async (req, res) => {
  const email = clean(req.body.email).toLowerCase(), password = req.body.password;
  const result = await pool.query('SELECT id,name,email,password_hash FROM users WHERE email=$1', [email]);
  if (!result.rowCount || typeof password !== 'string' || !(await bcrypt.compare(password, result.rows[0].password_hash))) return res.status(401).json({ error: 'Incorrect email or password.' });
  const { password_hash, ...user } = result.rows[0];
  res.json({ token: tokenFor(user), user, portfolio: await portfolioForUser(user.id) });
}));
app.get('/api/me', requireAuth, asyncRoute(async (req,res) => {
  const u = await pool.query('SELECT id,name,email,created_at FROM users WHERE id=$1',[req.user.id]);
  if (!u.rowCount) return res.status(404).json({error:'User not found.'});
  const portfolio = await portfolioForUser(req.user.id);
  const projects = portfolio ? (await pool.query('SELECT * FROM projects WHERE portfolio_id=$1 ORDER BY sort_order,created_at DESC',[portfolio.id])).rows : [];
  res.json({user:u.rows[0],portfolio,projects});
}));
app.put('/api/portfolio', requireAuth, asyncRoute(async (req,res) => {
  const allowedThemes = ['midnight','minimal','violet'];
  const { headline, bio, location, avatar_url, website_url, github_url, linkedin_url, resume_url, skills, theme, is_published, slug } = req.body;
  if (headline !== undefined && clean(headline).length > 180) return res.status(400).json({error:'Headline must be 180 characters or fewer.'});
  if (bio !== undefined && clean(bio).length > 5000) return res.status(400).json({error:'Bio must be 5000 characters or fewer.'});
  if (theme !== undefined && !allowedThemes.includes(theme)) return res.status(400).json({error:'Invalid theme.'});
  for (const [label, value] of [['Avatar URL',avatar_url],['Website URL',website_url],['GitHub URL',github_url],['LinkedIn URL',linkedin_url],['Resume URL',resume_url]]) {
    if (value !== undefined && clean(value) && !/^https?:\/\//i.test(clean(value))) return res.status(400).json({error:`${label} must start with http:// or https://.`});
    if (value !== undefined && clean(value).length > 2048) return res.status(400).json({error:`${label} is too long.`});
  }
  const nextSlug = slug === undefined ? undefined : slugify(slug);
  try {
    const r = await pool.query(`UPDATE portfolios SET headline=COALESCE($1,headline),bio=COALESCE($2,bio),location=COALESCE($3,location),avatar_url=COALESCE($4,avatar_url),website_url=COALESCE($5,website_url),github_url=COALESCE($6,github_url),linkedin_url=COALESCE($7,linkedin_url),resume_url=COALESCE($8,resume_url),skills=COALESCE($9,skills),theme=COALESCE($10,theme),is_published=COALESCE($11,is_published),slug=COALESCE($12,slug),updated_at=NOW() WHERE user_id=$13 RETURNING *`,
      [headline===undefined?null:clean(headline),bio===undefined?null:clean(bio),location===undefined?null:clean(location),avatar_url===undefined?null:clean(avatar_url),website_url===undefined?null:clean(website_url),github_url===undefined?null:clean(github_url),linkedin_url===undefined?null:clean(linkedin_url),resume_url===undefined?null:clean(resume_url),skills===undefined?null:arrayOfStrings(skills),theme??null,typeof is_published==='boolean'?is_published:null,nextSlug??null,req.user.id]);
    if (!r.rowCount) return res.status(404).json({error:'Portfolio not found.'});
    res.json({portfolio:r.rows[0]});
  } catch(e) { if(e.code==='23505') return res.status(409).json({error:'That portfolio URL is already in use.'}); throw e; }
}));
app.get('/api/projects', requireAuth, asyncRoute(async (req,res) => {
  const p = await portfolioForUser(req.user.id); if(!p) return res.json({projects:[]});
  res.json({projects:(await pool.query('SELECT * FROM projects WHERE portfolio_id=$1 ORDER BY sort_order,created_at DESC',[p.id])).rows});
}));
app.post('/api/projects', requireAuth, asyncRoute(async (req,res) => {
  const title=clean(req.body.title), description=clean(req.body.description), image_url=clean(req.body.image_url), project_url=clean(req.body.project_url), technologies=arrayOfStrings(req.body.technologies);
  if(title.length<1||title.length>160) return res.status(400).json({error:'Project title is required (160 characters maximum).'});
  const p=await portfolioForUser(req.user.id); if(!p) return res.status(404).json({error:'Portfolio not found.'});
  const r=await pool.query('INSERT INTO projects(portfolio_id,title,description,image_url,project_url,technologies) VALUES($1,$2,$3,$4,$5,$6) RETURNING *',[p.id,title,description.slice(0,5000),image_url,project_url,technologies]);
  res.status(201).json({project:r.rows[0]});
}));
app.put('/api/projects/:id', requireAuth, asyncRoute(async (req,res) => {
  const p=await portfolioForUser(req.user.id); if(!p) return res.status(404).json({error:'Portfolio not found.'});
  const {title,description,image_url,project_url,technologies,sort_order}=req.body;
  const r=await pool.query(`UPDATE projects SET title=COALESCE($1,title),description=COALESCE($2,description),image_url=COALESCE($3,image_url),project_url=COALESCE($4,project_url),technologies=COALESCE($5,technologies),sort_order=COALESCE($6,sort_order) WHERE id=$7 AND portfolio_id=$8 RETURNING *`,[title===undefined?null:clean(title),description===undefined?null:clean(description),image_url===undefined?null:clean(image_url),project_url===undefined?null:clean(project_url),technologies===undefined?null:arrayOfStrings(technologies),Number.isInteger(sort_order)?sort_order:null,req.params.id,p.id]);
  if(!r.rowCount) return res.status(404).json({error:'Project not found.'}); res.json({project:r.rows[0]});
}));
app.delete('/api/projects/:id', requireAuth, asyncRoute(async (req,res) => {
  const p=await portfolioForUser(req.user.id); if(!p) return res.status(404).json({error:'Portfolio not found.'});
  const r=await pool.query('DELETE FROM projects WHERE id=$1 AND portfolio_id=$2 RETURNING id',[req.params.id,p.id]); if(!r.rowCount) return res.status(404).json({error:'Project not found.'}); res.status(204).end();
}));
app.get('/api/public/search', asyncRoute(async (req,res) => {
  const q=clean(req.query.q).slice(0,100), like=`%${q.replace(/[\\%_]/g,'\\$&')}%`;
  const result=await pool.query(`SELECT p.slug,p.headline,p.bio,p.location,p.avatar_url,p.skills,p.theme,u.name FROM portfolios p JOIN users u ON u.id=p.user_id WHERE p.is_published=TRUE AND ($1='' OR u.name ILIKE $2 OR p.headline ILIKE $2 OR p.bio ILIKE $2 OR EXISTS(SELECT 1 FROM unnest(p.skills) s WHERE s ILIKE $2)) ORDER BY p.updated_at DESC LIMIT 50`,[q,like]);
  res.json({portfolios:result.rows});
}));
app.get('/api/public/portfolios/:slug', asyncRoute(async (req,res) => {
  const r=await pool.query(`SELECT p.id,p.slug,p.headline,p.bio,p.location,p.avatar_url,p.website_url,p.github_url,p.linkedin_url,p.resume_url,p.skills,p.theme,u.name FROM portfolios p JOIN users u ON u.id=p.user_id WHERE p.slug=$1 AND p.is_published=TRUE`,[req.params.slug]);
  if(!r.rowCount) return res.status(404).json({error:'Portfolio not found.'});
  const portfolio=r.rows[0], projects=(await pool.query('SELECT id,title,description,image_url,project_url,technologies FROM projects WHERE portfolio_id=$1 ORDER BY sort_order,created_at DESC',[portfolio.id])).rows;
  res.json({portfolio,projects});
}));
app.post('/api/contact/:slug', asyncRoute(async (req,res) => {
  const name=clean(req.body.name), email=clean(req.body.email).toLowerCase(), message=clean(req.body.message);
  if(name.length<2||name.length>100||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254||message.length<5||message.length>3000) return res.status(400).json({error:'Enter a name, valid email, and message (5–3000 characters).'});
  const p=await pool.query('SELECT id FROM portfolios WHERE slug=$1 AND is_published=TRUE',[req.params.slug]); if(!p.rowCount) return res.status(404).json({error:'Portfolio not found.'});
  await pool.query('INSERT INTO contact_messages(portfolio_id,sender_name,sender_email,message) VALUES($1,$2,$3,$4)',[p.rows[0].id,name,email,message]); res.status(201).json({message:'Message sent successfully.'});
}));
app.get('/api/messages', requireAuth, asyncRoute(async (req,res) => {
  const p=await portfolioForUser(req.user.id); if(!p) return res.json({messages:[]});
  res.json({messages:(await pool.query('SELECT id,sender_name,sender_email,message,is_read,created_at FROM contact_messages WHERE portfolio_id=$1 ORDER BY created_at DESC LIMIT 100',[p.id])).rows});
}));
app.patch('/api/messages/:id/read', requireAuth, asyncRoute(async (req,res) => {
  const p=await portfolioForUser(req.user.id); if(!p) return res.status(404).json({error:'Portfolio not found.'});
  const r=await pool.query('UPDATE contact_messages SET is_read=TRUE WHERE id=$1 AND portfolio_id=$2 RETURNING id,is_read',[req.params.id,p.id]); if(!r.rowCount) return res.status(404).json({error:'Message not found.'}); res.json({message:r.rows[0]});
}));
app.delete('/api/messages/:id', requireAuth, asyncRoute(async (req,res) => {
  const p=await portfolioForUser(req.user.id); if(!p) return res.status(404).json({error:'Portfolio not found.'});
  const r=await pool.query('DELETE FROM contact_messages WHERE id=$1 AND portfolio_id=$2 RETURNING id',[req.params.id,p.id]);
  if(!r.rowCount) return res.status(404).json({error:'Message not found.'}); res.status(204).end();
}));
app.use((err,_req,res,_next)=>{ console.error(err); if (err.type === 'entity.too.large') return res.status(413).json({error:'Request body is too large.'}); if(err.code==='23505') return res.status(409).json({error:'This value is already in use.'}); res.status(500).json({error:process.env.NODE_ENV==='production'?'Something went wrong.':'Server error. Check server logs and database configuration.'}); });
app.listen(PORT,()=>console.log(`FolioHub API listening on port ${PORT}`));
