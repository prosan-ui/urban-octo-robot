import pg from 'pg';
const { Pool } = pg;
if (!process.env.DATABASE_URL) console.warn('DATABASE_URL is not configured. API database requests will fail until configured.');
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : undefined,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});
pool.on('error', (err) => console.error('Unexpected PostgreSQL pool error:', err.message));
