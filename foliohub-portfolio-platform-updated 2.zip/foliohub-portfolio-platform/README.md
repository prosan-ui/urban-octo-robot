# FolioHub — Multi-user Portfolio Builder

A full-stack portfolio platform built with React, Vite, React Router, Express, and PostgreSQL. Users can register, edit a portfolio and social links, select a theme, add/edit/delete projects, publish a public page, search public portfolios, and manage incoming contact messages.

## Requirements
- Node.js 20+
- PostgreSQL 14+ (local or hosted)

## Project layout
- `client/` — React frontend and responsive styling
- `server/` — Express REST API, authentication, database access
- `server/sql/schema.sql` — database schema
- `netlify.toml` — SPA routing and Netlify build configuration

## Local setup
1. Create a database called `foliohub` in PostgreSQL.
2. Run the schema from the project root:
   ```bash
   psql "postgresql://USER:PASSWORD@HOST:5432/foliohub" -f server/sql/schema.sql
   ```
3. Copy `server/.env.example` to `server/.env` and set `DATABASE_URL`, a random `JWT_SECRET` of at least 32 characters, `CLIENT_URL=http://localhost:5173`, and `DB_SSL=false` for local PostgreSQL. For hosted PostgreSQL that requires TLS, set `DB_SSL=true`.
4. Copy `client/.env.example` to `client/.env`. Set `VITE_API_URL=http://localhost:4000/api`.
5. If you are upgrading an existing database, re-run `server/sql/schema.sql`; its `ALTER TABLE ... ADD COLUMN IF NOT EXISTS` statements add the new social-link columns safely.
6. From the project root, install dependencies:
   ```bash
   npm install
   npm install --prefix server
   npm install --prefix client
   ```
7. Start both apps:
   ```bash
   npm run dev
   ```
8. Open `http://localhost:5173`. API health check: `http://localhost:4000/api/health`.

## Features
- Account registration/login with bcrypt password hashing and signed JWTs
- Private portfolio editor with profile, social links, skills, slug, theme, publish state
- Add, update, and delete projects; edit and delete inbox messages
- Public portfolio pages at `/p/:slug`
- Public search at `/explore`
- Public contact form and private message inbox
- Rate limiting for authentication and contact endpoints, Helmet security headers, CORS allow-list

## REST API overview
- `GET /api/health`
- `POST /api/auth/register`, `POST /api/auth/login`
- `GET /api/me`
- `PUT /api/portfolio`
- `GET /api/projects`, `POST /api/projects`, `PUT /api/projects/:id`, `DELETE /api/projects/:id`
- `GET /api/public/search?q=...`, `GET /api/public/portfolios/:slug`
- `POST /api/contact/:slug`
- `GET /api/messages`, `PATCH /api/messages/:id/read`, `DELETE /api/messages/:id`

Private routes require `Authorization: Bearer <token>`. The client handles this header for authenticated requests.

## Deploy online
### PostgreSQL (Neon or other managed PostgreSQL)
1. Create a database and run `server/sql/schema.sql` in its SQL editor.
2. Copy its connection string. Use SSL settings required by your provider; set `DB_SSL=true` for providers that require TLS with the configuration in this project.

### API (Render Web Service)
1. Push the repository to GitHub.
2. Create a Render Web Service using the repository and `server` as the root directory.
3. Build command: `npm install`; start command: `npm start`.
4. Set `DATABASE_URL`, `JWT_SECRET` (random, 32+ characters), `NODE_ENV=production`, `DB_SSL=true` if required, and `CLIENT_URL` to your exact deployed frontend origin. For multiple origins, use a comma-separated allow-list.
5. Deploy and verify `/api/health`.

### Frontend (Netlify)
1. Import the repository into Netlify.
2. Base directory: `client`; build command: `npm run build`; publish directory: `dist` (relative to base).
3. Set `VITE_API_URL` to `https://YOUR-API-DOMAIN/api` and redeploy.
4. Update the API's `CLIENT_URL` to the Netlify site origin and redeploy the API.

## Production checklist
- Use a unique random `JWT_SECRET` and never commit `.env` files.
- Use HTTPS for the frontend and API.
- Configure provider-specific PostgreSQL TLS and backups.
- Consider secure HttpOnly cookie sessions, email verification, password reset, account deletion, moderation/reporting, and additional abuse prevention before operating at scale.
- Avatar, social links, resume, and project images currently use URLs; direct file upload is not included.
- Automated tests, email delivery, and OAuth are not included in this starter.
