const BASE = (import.meta.env.VITE_API_URL || 'http://localhost:4000/api').replace(/\/$/, '');
export function getToken(){ return localStorage.getItem('foliohub_token'); }
export function setToken(token){ if(token) localStorage.setItem('foliohub_token',token); else localStorage.removeItem('foliohub_token'); }
export async function api(path, options={}){
  const headers={'Content-Type':'application/json',...(options.headers||{})};
  const token=getToken(); if(token) headers.Authorization=`Bearer ${token}`;
  const response=await fetch(`${BASE}${path}`,{...options,headers});
  if(response.status===204) return null;
  const data=await response.json().catch(()=>({error:'Unexpected server response.'}));
  if(!response.ok) throw new Error(data.error||'Request failed');
  return data;
}
