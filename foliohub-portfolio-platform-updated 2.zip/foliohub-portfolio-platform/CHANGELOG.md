# Changelog

## 1.1.0
- Added public website, GitHub, LinkedIn, and resume links to portfolio profiles.
- Added project editing in the dashboard, in addition to create/delete.
- Added message deletion to the private inbox.
- Added safe SQL migration statements for the new profile URL columns.
- Improved URL validation and request-body error handling in the API.

## 1.0.0
- Initial multi-user portfolio builder with authentication, public pages, project management, themes, search, and contact messages.
